// pages/lanhdaoban.js
import { useEffect, useState } from 'react';
import axios from 'axios';
import LanhDaoBanModal from '../components/LanhDaoBanModal';

export default function LanhDaoBan() {
  const [reportData, setReportData] = useState([]);
  const [showDialog, setShowDialog] = useState(false);
  const [evaluationResult, setEvaluationResult] = useState('');
  const [conclusionText, setConclusionText] = useState('');
  const [recommendationText, setRecommendationText] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLatest = async () => {
      try {
        const res = await axios.get('/api/get-latest-report');
        setReportData(res.data.rows || []);
        setConclusionText(res.data.conclusion || '');
        setRecommendationText(res.data.recommendation || '');
      } catch (err) {
        console.error('Lỗi tải báo cáo:', err);
        setReportData([]);
      } finally {
        setLoading(false);
      }
    };
    fetchLatest();
  }, []);

  const handleAI = async () => {
    setShowDialog(true);
    setEvaluationResult('Đang đánh giá...');
    try {
      const res = await fetch('/api/evaluate-ai', { method: 'POST' });
      const data = await res.json();
      setEvaluationResult(data.result || 'Không có kết quả');
    } catch (error) {
      setEvaluationResult('Đánh giá thất bại.');
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold mb-4">Báo cáo tuần mới nhất</h1>
      {loading ? (
        <p>Đang tải dữ liệu...</p>
      ) : reportData.length === 0 ? (
        <p>Không có dữ liệu để hiển thị</p>
      ) : (
        <>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm border">
              <thead className="bg-gray-100">
                <tr>
                  <th className="border p-2">STT</th>
                  <th className="border p-2">Công việc</th>
                  <th className="border p-2">Lý trình</th>
                  <th className="border p-2">Đơn vị</th>
                  <th className="border p-2">Thiết kế</th>
                  <th className="border p-2">Lũy kế tuần trước</th>
                  <th className="border p-2">Kế hoạch tuần trước</th>
                  <th className="border p-2">Thực hiện</th>
                  <th className="border p-2">Lũy kế đến nay</th>
                  <th className="border p-2">% Hoàn thành trong tuần</th>
                  <th className="border p-2">% Hoàn thiện theo dự án</th>
                  <th className="border p-2">Ghi chú</th>
                </tr>
              </thead>
              <tbody>
                {reportData.map((row, idx) => (
                  <tr key={idx}>
                    <td className="border p-1">{row['STT']}</td>
                    <td className="border p-1 whitespace-nowrap text-ellipsis overflow-hidden max-w-[200px]">{row['Công việc']}</td>
                    <td className="border p-1">{row['Lý trình']}</td>
                    <td className="border p-1">{row['Đơn vị']}</td>
                    <td className="border p-1">{row['Thiết kế']}</td>
                    <td className="border p-1">{row['Lũy kế tuần trước']}</td>
                    <td className="border p-1">{row['Kế hoạch tuần trước']}</td>
                    <td className="border p-1">{row['Thực hiện']}</td>
                    <td className="border p-1">{row['Lũy kế đến nay']}</td>
                    <td className="border p-1">{row['% Hoàn thành trong tuần']}</td>
                    <td className="border p-1">{row['% Hoàn thiện theo dự án']}</td>
                    <td className="border p-1">{row['Ghi chú']}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-4 p-4 border border-gray-300 bg-gray-50">
            <strong>Kết luận:</strong>
            <p className="whitespace-pre-line">{conclusionText}</p>
          </div>

          <div className="mt-2 p-4 border border-gray-300 bg-gray-50">
            <strong>Kiến nghị:</strong>
            <p className="whitespace-pre-line">{recommendationText}</p>
          </div>

          <div className="mt-6">
            <button
              onClick={handleAI}
              className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
            >
              Đánh giá bằng AI
            </button>
          </div>

          <LanhDaoBanModal
            isOpen={showDialog}
            onClose={() => setShowDialog(false)}
            evaluationResult={evaluationResult}
          />
        </>
      )}
    </div>
  );
}
