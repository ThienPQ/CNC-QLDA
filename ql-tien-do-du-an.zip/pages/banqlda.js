// pages/banqlda.js
import { useState } from 'react';
import axios from 'axios';

export default function BanQLDA() {
  const [file, setFile] = useState(null);
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const handleUpload = async () => {
    if (!file || !fromDate || !toDate) {
      alert('Vui lòng chọn file và ngày');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await axios.post('/api/upload-report', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      alert(res.data.message);
    } catch (error) {
      console.error(error);
      alert('Tải lên thất bại.');
    }
  };

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-xl font-bold">Gửi báo cáo tuần</h1>
      <div className="space-x-2">
        <label>Từ ngày:</label>
        <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
        <label>Đến ngày:</label>
        <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />
      </div>
      <input type="file" accept=".xlsx" onChange={(e) => setFile(e.target.files[0])} />
      <button
        onClick={handleUpload}
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Gửi báo cáo
      </button>
    </div>
  );
}
