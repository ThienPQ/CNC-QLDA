// pages/_app.js
import '../Styles/globals.css'

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />
}
