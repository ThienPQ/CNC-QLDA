
// pages/api/evaluate-ai.js
import fs from 'fs';
import path from 'path';
import formidable from 'formidable';
import { OpenAI } from 'openai';
import xlsx from 'xlsx';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  try {
    const { filename } = req.body;
    const uploadsDir = path.join(process.cwd(), 'uploads');
    const allFiles = fs.readdirSync(uploadsDir).filter(f => f.endsWith('.xlsx')).sort();

    const latestFile = path.join(uploadsDir, filename);
    const prevFile = allFiles.length >= 2 ? path.join(uploadsDir, allFiles[allFiles.length - 2]) : null;
    const contractFile = path.join(process.cwd(), 'PLHD.xlsx');

    const readSheet = (filePath) => {
      const workbook = xlsx.readFile(filePath);
      const sheet = workbook.Sheets["Mẫu số 11C"];
      return xlsx.utils.sheet_to_json(sheet, { defval: '' });
    };

    const latestData = readSheet(latestFile);
    const prevData = prevFile ? readSheet(prevFile) : [];
    const contractData = readSheet(contractFile);

    const makeSummary = (rows) => {
      return rows.map(r => `- ${r["Công việc"]}: KL thực hiện ${r["Thực hiện"]}, KL lũy kế ${r["Lũy kế"]}, ghi chú: ${r["Ghi chú"]}`).join('\n');
    };

    const latestSummary = makeSummary(latestData);
    const prevSummary = makeSummary(prevData);
    const contractSummary = makeSummary(contractData);

    const prompt = `Bạn là chuyên gia đánh giá tiến độ thi công công trình giao thông. Dưới đây là 3 nguồn dữ liệu:\n
1. Báo cáo tuần Mới nhất:\n${latestSummary}\n
2. Báo cáo tuần Trước:\n${prevSummary}\n
3. Số liệu trong hợp đồng (PLHD):\n${contractSummary}\n
Yêu cầu:\n- So sánh báo cáo tuần mới nhất với tuần trước: tiến độ tăng/giảm, thay đổi trong ghi chú\n- Tổng hợp khối lượng cộng dồn từ các báo cáo đã nộp, so sánh với PLHD\n- Đánh giá tổng thể mức độ hoàn thành theo % so với PLHD\n- Gợi ý chỉ đạo hoặc xử lý nếu có nguy cơ chậm tiến độ\n
Viết ngắn gọn, rõ ràng theo dạng mục.`;

    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        {
          role: 'system',
          content: 'Bạn là chuyên gia quản lý dự án hạ tầng giao thông, nhiệm vụ là đánh giá tiến độ thi công và đưa ra đề xuất xử lý.'
        },
        { role: 'user', content: prompt },
      ],
      temperature: 0.5,
    });

    const result = completion.choices[0].message.content;
    res.status(200).json({ result });
  } catch (error) {
    console.error("Lỗi AI đánh giá:", error);
    res.status(500).json({ error: 'Đánh giá AI thất bại' });
  }
}
