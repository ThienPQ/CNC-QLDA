// pages/api/get-latest-report.js
import path from 'path';
import fs from 'fs';
import xlsx from 'xlsx';

export default function handler(req, res) {
  try {
    const uploadsDir = path.join(process.cwd(), 'uploads');
    const files = fs.readdirSync(uploadsDir)
      .filter(file => file.endsWith('.xlsx'))
      .sort((a, b) => {
        return fs.statSync(path.join(uploadsDir, b)).mtime - fs.statSync(path.join(uploadsDir, a)).mtime;
      });

    if (files.length === 0) return res.status(404).json({ error: 'Không có báo cáo' });

    const latestFile = path.join(uploadsDir, files[0]);
    const workbook = xlsx.readFile(latestFile);
    const sheet = workbook.Sheets[workbook.SheetNames[0]];

    const data = xlsx.utils.sheet_to_json(sheet, { range: 'A34:Q90', header: 1 });
    const headers = data[0];
    const rows = data.slice(1).map(row => {
      const obj = {};
      headers.forEach((header, i) => {
        obj[header] = row[i] || '';
      });
      return obj;
    });

    const conclusion = sheet['A115']?.v || '';
    const recommendation = sheet['A116']?.v || '';
    const conclusionText = `Kết luận: ${conclusion}\nKiến nghị: ${recommendation}`;

    res.status(200).json({ rows, conclusion: conclusionText });
  } catch (e) {
    console.error('Lỗi đọc báo cáo:', e);
    res.status(500).json({ error: 'Lỗi xử lý file Excel' });
  }
}
