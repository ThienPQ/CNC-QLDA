// pages/api/upload-report.js
import formidable from 'formidable';
import fs from 'fs';
import path from 'path';

// Tắt bodyParser mặc định
export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Chỉ hỗ trợ POST' });
  }

  const uploadDir = path.join(process.cwd(), '/uploads');
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
  }

  const form = formidable({ multiples: false, uploadDir, keepExtensions: true });

  form.parse(req, async (err, fields, files) => {
    if (err || !files.file) {
      console.error('Lỗi khi tải lên:', err);
      return res.status(400).json({ message: 'Tải lên thất bại.' });
    }

    const uploadedFile = files.file[0];
    const originalName = uploadedFile.originalFilename || 'report.xlsx';
    const newPath = path.join(uploadDir, originalName);

    try {
      fs.renameSync(uploadedFile.filepath, newPath);
      console.log('Đã lưu file:', newPath);
      return res.status(200).json({ message: 'Tải lên thành công' });
    } catch (e) {
      console.error('Lỗi ghi file:', e);
      return res.status(500).json({ message: 'Không thể lưu file' });
    }
  });
}
